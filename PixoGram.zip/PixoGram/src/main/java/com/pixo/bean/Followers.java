package com.pixo.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Followers {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int followId;
	private int followerId;
	private int followingId;
	private String followerName;
	private String followingName;
	
	public Followers(){}

	public int getFollowId() {
		return followId;
	}

	public void setFollowId(int followId) {
		this.followId = followId;
	}

	public int getFollowerId() {
		return followerId;
	}

	public void setFollowerId(int followerId) {
		this.followerId = followerId;
	}

	public int getFollowingId() {
		return followingId;
	}

	public void setFollowingId(int followingId) {
		this.followingId = followingId;
	}

	public String getFollowerName() {
		return followerName;
	}

	public void setFollowerName(String followerName) {
		this.followerName = followerName;
	}

	public String getFollowingName() {
		return followingName;
	}

	public void setFollowingName(String followingName) {
		this.followingName = followingName;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + followId;
		result = prime * result + followerId;
		result = prime * result + ((followerName == null) ? 0 : followerName.hashCode());
		result = prime * result + followingId;
		result = prime * result + ((followingName == null) ? 0 : followingName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Followers other = (Followers) obj;
		if (followId != other.followId)
			return false;
		if (followerId != other.followerId)
			return false;
		if (followerName == null) {
			if (other.followerName != null)
				return false;
		} else if (!followerName.equals(other.followerName))
			return false;
		if (followingId != other.followingId)
			return false;
		if (followingName == null) {
			if (other.followingName != null)
				return false;
		} else if (!followingName.equals(other.followingName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Followers [followId=" + followId + ", followerId=" + followerId + ", followingId=" + followingId
				+ ", followerName=" + followerName + ", followingName=" + followingName + "]";
	}
	
	
	
}
