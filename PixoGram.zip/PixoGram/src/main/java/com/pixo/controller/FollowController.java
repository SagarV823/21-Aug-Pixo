package com.pixo.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.pixo.bean.AccountDetails;
import com.pixo.bean.Followers;
import com.pixo.dao.UserDAO;
import com.pixo.service.UserService;

@Controller
public class FollowController {

	@Autowired
	public UserService userService;
	
	@Autowired
	public UserDAO userDAO;
	
	static Logger logger = Logger.getLogger(UserController.class);
	
	@RequestMapping(value="follow")
	 public ModelAndView follow(HttpServletRequest request)
	 {
		 ModelAndView mv=new ModelAndView();	
	     HttpSession session=request.getSession();
	     
	     String followeremailId=(String)request.getSession().getAttribute("EmailId");
	     AccountDetails follower=userService.getUser(followeremailId);
	     String followerFirstName=follower.getFirstName();
	     String followerLastName=follower.getLastName();
	     String followerName=followerFirstName.concat(" "+followerLastName);
	     int followerId=(int)request.getSession().getAttribute("UserId");
	     	     
	     int followingId=(int)request.getSession().getAttribute("searchedUserId");	   	     
	     AccountDetails following=userService.getUserDetails(followingId);	     
	     String followingFirstName=following.getFirstName();
	     String followingLastName=following.getLastName();
	     String followingName=followingFirstName.concat(" "+followingLastName);
	    	   	     
	     Followers followers=new Followers();
	     followers.setFollowerId(followerId);
	     followers.setFollowerName(followerName);
	     followers.setFollowingId(followingId);
	     followers.setFollowingName(followingName);	     	     
	     
	     userService.Follow(followers);
	     
	     AccountDetails myself=userService.getUser(followeremailId);
	     String fname=myself.getFirstName();
		 String lname=myself.getLastName();
		 mv.addObject("username",fname);
		 mv.addObject("lastname",lname); 
		 
	     mv.addObject("userdetails",following);
	     mv.setViewName("UserDetails");
	     return mv;
		 
	 }	
	
	 @RequestMapping(value="unfollow")
	 public ModelAndView unFollow(HttpServletRequest request)
	 {
		 ModelAndView mv=new ModelAndView();	
	     HttpSession session=request.getSession();
	     
	     String followeremailId=(String)request.getSession().getAttribute("EmailId");
	     AccountDetails follower=userService.getUser(followeremailId);
	     int followerId=(int)request.getSession().getAttribute("UserId");	     	     
	     int followingId=(int)request.getSession().getAttribute("searchedUserId");	   	     
	     AccountDetails following=userService.getUserDetails(followingId);	     	    	   	          
	    
	     userService.unFollow(followerId,followingId);
	     
	     AccountDetails myself=userService.getUser(followeremailId);
	     String fname=myself.getFirstName();
		 String lname=myself.getLastName();
		 mv.addObject("username",fname);
		 mv.addObject("lastname",lname); 
		 
	     mv.addObject("userdetails",following);
	     mv.setViewName("UserDetails");
	     return mv;	 
	 }
	 
	 @RequestMapping(value="unFollowNow")
	 public ModelAndView unFollowNow(HttpServletRequest request,@RequestParam("id") int userId)
	 {
		 ModelAndView mv=new ModelAndView();	
	     HttpSession session=request.getSession();
	     
	     String followeremailId=(String)request.getSession().getAttribute("EmailId");
	     AccountDetails follower=userService.getUser(followeremailId);
	     int followerId=(int)request.getSession().getAttribute("UserId");	     	     
	     int followingId=userId;	   	     
	     AccountDetails following=userService.getUserDetails(followingId);	     	    	   	          
	    
	     userService.unFollow(followerId,followingId);
	     
	     AccountDetails myself=userService.getUser(followeremailId);
	     String fname=myself.getFirstName();
		 String lname=myself.getLastName();
		 mv.addObject("username",fname);
		 mv.addObject("lastname",lname); 
		 
		 int myId=followerId;
		 List<Followers> allFollowing=userService.meFollowing(myId);
		 mv.addObject("meFollowing",allFollowing);
	     mv.addObject("userdetails",following);
	     mv.setViewName("Following");
	     return mv;	 
	 }
	 
	 @RequestMapping(value="showFollowers")
	 public ModelAndView AllFollowers(HttpServletRequest request)
	 {
		 ModelAndView mv=new ModelAndView();	
	     HttpSession session=request.getSession();	     	     	     
	     	    	   	          	    	    	     
	     String myEmail=(String)request.getSession().getAttribute("EmailId");
	     AccountDetails myself=userService.getUser(myEmail);
	     String fname=myself.getFirstName();
		 String lname=myself.getLastName();
		 int myId=myself.getId();
		 List<Followers> allFollowers=userService.myFollowers(myId);
		 
		 mv.addObject("username",fname);
		 mv.addObject("lastname",lname); 
		 mv.addObject("myFollowers",allFollowers);
	     mv.setViewName("FollowersFollowing");
	     return mv;	 
	 }
	 
	 @RequestMapping(value="following")
	 public ModelAndView meFollowing(HttpServletRequest request)
	 {
		 ModelAndView mv=new ModelAndView();	
	     HttpSession session=request.getSession();	     	     	     
	     	    	   	          	    	    	     
	     String myEmail=(String)request.getSession().getAttribute("EmailId");
	     AccountDetails myself=userService.getUser(myEmail);
	     String fname=myself.getFirstName();
		 String lname=myself.getLastName();
		 int myId=myself.getId();
		 List<Followers> allFollowing=userService.meFollowing(myId);
		 
		 mv.addObject("username",fname);
		 mv.addObject("lastname",lname); 
		 mv.addObject("meFollowing",allFollowing);
	     mv.setViewName("Following");
	     return mv;	 
	 }
}
